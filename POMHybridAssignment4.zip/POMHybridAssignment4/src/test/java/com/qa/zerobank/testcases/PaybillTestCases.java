package com.qa.zerobank.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.pages.PaybillsPage;

public class PaybillTestCases extends TestBase {
		HomePage homePage;
		LogInPage logInPage;
		AccountSummaryPage accountSummaryPage;
		PaybillsPage paybillpage;
		
	
	public PaybillTestCases()  {
		super();
	}
	
	@BeforeMethod
	public void beforeMethod()    {

		 initialization();
		 homePage =new HomePage();
		 logInPage =new LogInPage();
		 accountSummaryPage =new AccountSummaryPage();
		 paybillpage =new PaybillsPage();
	}

	@AfterMethod
	public void afterMethod()  {
		
		driver.close();
		driver.quit();
		
	}
	
	@Test(groups ="smoke")
	public void validateLogInPage()  {
		logInPage =homePage.clickOnSignInButton();
		logInPage.assertLogInPageTitle();
	}

	@Test(groups ="smoke")
	public void validateLogInFunctionality()  {
		logInPage =homePage.clickOnSignInButton();
		accountSummaryPage = logInPage.logIn();
		accountSummaryPage.assertAccountSummaryPageTitle();
	} 
	@Test(groups ="smoke")
	public void validatePaybillsPage()  {
		logInPage =homePage.clickOnSignInButton();
		accountSummaryPage = logInPage.logIn();
		paybillpage =accountSummaryPage.OpenPaybillpage();
		paybillpage.assertPaybillsPageTitle();
		
	}
	
	
	@Test(groups ="smoke")
	public void validateAlert()  {
		logInPage =homePage.clickOnSignInButton();
		accountSummaryPage = logInPage.logIn();
		paybillpage =accountSummaryPage.OpenPaybillpage();
		paybillpage.assertPaybillsPageTitle();
		paybillpage.HandleAlert();
		
	}
	
	
	@Test (groups ="Regression")
	public void WrongPageTitle() {
		logInPage =homePage.clickOnSignInButton();
		accountSummaryPage = logInPage.logIn();
		paybillpage =accountSummaryPage.OpenPaybillpage();
		paybillpage.assertWrongTitle();
	}
	
	@Test (groups ="Regression")
	public void dontvalidateAlert()  {
		logInPage =homePage.clickOnSignInButton();
		accountSummaryPage = logInPage.logIn();
		paybillpage =accountSummaryPage.OpenPaybillpage();
		paybillpage.assertPaybillsPageTitle();
		paybillpage.DONThandleAlert();		
	}
	
	
}
