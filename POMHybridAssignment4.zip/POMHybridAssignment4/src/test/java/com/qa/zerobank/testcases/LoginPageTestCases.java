package com.qa.zerobank.testcases;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;

public class LoginPageTestCases extends TestBase {
	HomePage homePage;
	LogInPage logInPage;
	AccountSummaryPage accountSummaryPage;
	



public LoginPageTestCases()  {
	super();
}

@BeforeMethod
public void beforeMethod()    {

	 initialization();
	 homePage =new HomePage();
	 logInPage =new LogInPage();
	 accountSummaryPage =new AccountSummaryPage();
}

@AfterMethod
public void afterMethod()  {
	
	driver.close();
	driver.quit();
	
}

@Test(groups ="smoke")
public void validateLogInPage()  {
	logInPage =homePage.clickOnSignInButton();
	logInPage.assertLogInPageTitle();
}

@Test(groups ="Regression")
public void loginwithwrongpass() {
	logInPage =homePage.clickOnSignInButton();
	logInPage.wrongpassword();
	assertEquals(driver.getTitle(), "Zero - Account Summary");
}

@Test(groups ="Regression")
public void loginwithwronguid()  {
	logInPage =homePage.clickOnSignInButton();
	logInPage.wronguserid();
	assertEquals(driver.getTitle(), "Zero - Account Summary");
}
@Test(groups ="smoke")
public void validateLogInFunctionality()  {
	logInPage =homePage.clickOnSignInButton();
	accountSummaryPage = logInPage.logIn();
	accountSummaryPage.assertAccountSummaryPageTitle();
}

}
