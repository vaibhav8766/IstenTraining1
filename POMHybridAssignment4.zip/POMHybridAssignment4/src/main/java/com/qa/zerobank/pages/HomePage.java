package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class HomePage extends TestBase {
	
	
	//object Repository
		@FindBy(id="signin_button")
		WebElement signInButton;
		
		@FindBy(name="searchTerm")
		WebElement searchBox;
		
		@FindBy(linkText="Zero Bank")
		WebElement brandLinkZeroBank;
		
		@FindBy(css = "#online-banking")
		WebElement buttonMoreServices;
		
		@FindBy(className="brand")
		WebElement brandLogo;
		
		@FindBy(xpath="//a[contains(@href,'/about/legal/#privacy')][1]")
		WebElement linkone ;
		
		@FindBy(xpath="//a[contains(@href,'/about/legal/#privacy')][2]")
		WebElement linktwo ;
		
		@FindBy(xpath="//strong[contains(text(),'Home')]")
		WebElement Home;
		
		@FindBy(xpath="//strong[contains(text(),'Online Banking')]")
		WebElement OnlineBanking;
		
		@FindBy(xpath="//strong[contains(text(),'Feedback')]")
		WebElement Feedback;
		
		@FindBy(css = "#account_activity_link")
		WebElement CheckingAccountActivity;
		
		@FindBy(xpath="//img[contains(@src,'main_carousel_1.jpg')]")
		WebElement FirstImage;
		
		@FindBy(xpath="//span[@id='transfer_funds_link']")
		WebElement TransferFunds;
		
		@FindBy(xpath="//span[@id='money_map_link']")
		WebElement MyMoneyMap;
		
		@FindBy(css = "#download_webinspect_link")
		WebElement DownloadWebinspectLink;
		
		@FindBy(xpath = "//span[@id='terms_of_use_link']")
		WebElement TermsOfUse;
		
		@FindBy(xpath = "//span[@id='contact_hp_link']")
		WebElement ContactMicroFocus;
		
		@FindBy(xpath = "//span[@id='privacy_statement_link']")
		WebElement PrivacyStatement;
		
		@FindBy(xpath = "//a[@class='carousel-control custom left']")
		WebElement LeftCarousel;
		
		@FindBy(xpath = "//a[@class='carousel-control custom right']")
		WebElement RightCarousel;
		
		public HomePage()  {
			PageFactory.initElements(driver, this);
		}
		
		public void assertHomePageTitle() {
			assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards", "Home page title assert Failed");
		}
		
		public boolean validateBrandLogo()  {
			return brandLogo.isDisplayed();
		}
		
		public LogInPage clickOnSignInButton() {
			signInButton.click();
			return new LogInPage();
		}
		
}
