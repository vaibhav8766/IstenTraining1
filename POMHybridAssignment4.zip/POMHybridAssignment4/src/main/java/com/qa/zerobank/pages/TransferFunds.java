package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.zerobank.base.TestBase;

public class TransferFunds extends TestBase {
	
	////// OBJECT REPOSITORY  ////////
	
	@FindBy(linkText ="Transfer Funds") WebElement TransferFunds ;
	@FindBy(xpath = "//h2[contains(text(),'Transfer Money & Make Payments')]") WebElement Title ;
	@FindBy(xpath = "//select[@id='tf_fromAccountId']") WebElement FromAccountDropdown ;
	@FindBy(xpath = "//select[@id='tf_toAccountId']") WebElement ToAccountDropdown ;
	
	@FindBy(xpath = "//input[@id='tf_amount']") WebElement Amounttab ;
	@FindBy(xpath = "//input[@id='tf_description']") WebElement description ;
	@FindBy(xpath = "//button[@id='btn_submit']") WebElement continuebutton ;
	
	@FindBy(xpath = "//button[@id='btn_submit']") WebElement submitbutton ;
	@FindBy(xpath = "//a[@id='btn_cancel']") WebElement cancelbutton ;
	
	// constructor
    public TransferFunds() {
        PageFactory.initElements(driver, this);
    }
    
    // assert title
    public void assertTransferFundsPageTitle() {
        assertEquals(driver.getTitle(), "Zero - Transfer Funds");
    }
    
    public void TransferFund()  {
    	TransferFunds.click();
    	
    	FromAccountDropdown.click();
    	Select dd1= new Select(FromAccountDropdown);
    	dd1.selectByIndex(2);
    	
    	ToAccountDropdown.click();
    	Select dd2 =new Select(ToAccountDropdown);
    	dd2.selectByIndex(2);
    	
    	Amounttab.sendKeys("1000");
    	Amounttab.sendKeys(Keys.ENTER);
    	
    	continuebutton.click();
    	
    }
    
    public void dontassertTransferFundsPageTitle() {
        assertEquals(driver.getTitle(), "ZeroTransfer Funds");
    }
    
    
	
	
}
