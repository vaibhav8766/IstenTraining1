package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class PaybillsPage extends TestBase{

	//object Repository
	 @FindBy(id="pay_bills_tab") WebElement pay_bills_tab;
	 @FindBy(xpath ="//a[contains(text(),'Purchase Foreign Currency')]") WebElement PurchaseForeignCurrency;
	 @FindBy(id="purchase_cash") WebElement purchaseCashButton;
	
	 
	
	//constructor
	 
	 public PaybillsPage()  {
	        PageFactory.initElements(driver, this);
	    }

	//Assert Title
	 
	 public void assertPaybillsPageTitle() {
		 
		  driver.findElement(By.xpath("//a[contains(text(),'Pay Bills')]")).click();
	        assertEquals(driver.getTitle(), "Zero - Pay Bills");
	       
	    }
	 
	 public void assertWrongTitle()   {
		 driver.findElement(By.xpath("//a[contains(text(),'Pay Bills')]")).click();
	        assertEquals(driver.getTitle(), "ZerPay Bills");
	       
	 }
	 
	 public void HandleAlert() {
		 
		 PurchaseForeignCurrency.click();
		 purchaseCashButton.click();
		 Alert TAlert=driver.switchTo().alert();
		 String alerttxt=TAlert.getText();
		    System.out.println("The alert is "+ alerttxt);
			TAlert.getText();
			TAlert.accept();
		 
	 }
	 
	 public void DONThandleAlert() {
		 PurchaseForeignCurrency.click();
		 purchaseCashButton.click();
		 driver.switchTo().frame(0);
	 }
}
