package com.qa.zerobank.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.pages.TransferFunds;

public class TransferFundsTestCases extends TestBase {
	
	public class PaybillTestCases extends TestBase {
		HomePage homePage;
		LogInPage logInPage;
		AccountSummaryPage accountSummaryPage;
		TransferFunds transferfundspage;
		
public PaybillTestCases()  {
	super();
}

@BeforeMethod
public void beforeMethod()    {

	 initialization();
	 homePage =new HomePage();
	 logInPage =new LogInPage();
	 accountSummaryPage =new AccountSummaryPage();
	 transferfundspage =new TransferFunds();
}

@AfterMethod
public void afterMethod()  {
	
	driver.close();
	driver.quit();
	
}
@Test (groups ="smoke")
public void Transferfundss()   {
	logInPage =homePage.clickOnSignInButton();
	accountSummaryPage = logInPage.logIn();
    transferfundspage= accountSummaryPage.openTransferFunds();
    transferfundspage.assertTransferFundsPageTitle();
    transferfundspage.TransferFund();
    
} 
@Test(groups ="smoke")
public void RightTitle() {
	logInPage =homePage.clickOnSignInButton();
	accountSummaryPage = logInPage.logIn();
    transferfundspage= accountSummaryPage.openTransferFunds();
    transferfundspage.assertTransferFundsPageTitle();
	}

@Test (groups ="Regression")
public void wrongTitle() {
logInPage =homePage.clickOnSignInButton();
accountSummaryPage = logInPage.logIn();
transferfundspage= accountSummaryPage.openTransferFunds();
transferfundspage.dontassertTransferFundsPageTitle();
}


	}
}
