package com.zerobank.qa.TestCode;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class Feedback_feature {

	public static WebDriver driver;
	 @Given("^A \"([^\"]*)\" browser initialized$")
	 public void initiateBrowser(String browser)  {
	 //set system properties
		 System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");
	 driver =new ChromeDriver();
	 driver.manage().window().maximize();
	 driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	 }
	 
	 @And("^Open application \"([^\"]*)\"$")
	 public void OpenApp(String url) {        
	     //open URL into browser
	     driver.get(url);
	     assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");    
	 }
	 @And("^I click on Feedback tab on home page$")
	 public void clickOnfeedbacktab() {
	     driver.findElement(By.xpath("//strong[contains(text(),'Feedback')]")).click();   
	 }

	 @Given("^I am on feedback page$")
	 public void i_am_on_feedback_page() {
	     assertEquals(driver.getTitle(), "Zero - Contact Us");    
	 }
	 
@When("^I enter username as \"([^\"]*)\" and Mailid as \"([^\"]*)\" and Subject as \"([^\"]*)\" and Textbox as \"([^\"]*)\"$")
public void i_enter_details_except_one_field_kept_blank(String name, String mailid,String subject,String textbox) {
	     driver.findElement(By.xpath("//input[@id='name']")).sendKeys(name);
	     driver.findElement(By.xpath("//input[@id='email']")).sendKeys(mailid);   
	     driver.findElement(By.xpath("//input[@id='subject']")).sendKeys(subject);
	     driver.findElement(By.xpath("//textarea[@id='comment']")).sendKeys(textbox);
	     
	 }
@When("^Click on Signin button$")
public void click_on_sendmassage_button() {
	driver.findElement(By.xpath("//input[@type='submit']")).click();
	}




}
