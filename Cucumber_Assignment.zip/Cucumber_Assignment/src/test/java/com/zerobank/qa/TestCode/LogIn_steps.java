package com.zerobank.qa.TestCode;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LogIn_steps {
 public static WebDriver driver;
 
 @Given("^A \"([^\"]*)\" browser initialized$")
 public void initiateBrowser(String browser)  {
 //set system properties
	 System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");
 driver =new ChromeDriver();
 driver.manage().window().maximize();
 driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
 }
 
 @And("^Open application \"([^\"]*)\"$")
 public void OpenApp(String url) {        
     //open URL into browser
     driver.get(url);
     assertEquals(driver.getTitle(), "OrangeHRM");    
 }

 @And("^I click on Signin button on home page$")
 public void clickOnSignInButton() {
     driver.findElement(By.id("signin_button")).click();        
 }

 @Given("^I am on login page$")
 public void i_am_on_login_page() {
    driver.getTitle();  
 }

 @When("^I enter user id as \"([^\"]*)\" and password as \"([^\"]*)\"$")
 public void i_enter_user_id_as_and_password_as(String username, String password) {
     driver.findElement(By.id("user_login")).sendKeys(username);
     driver.findElement(By.id("user_password")).sendKeys(password);        
 }

 @When("^Click on Signin button$")
 public void click_on_Signin_button() {
     driver.findElement(By.name("submit")).click();

     
 }

 @Then("^I validate that I am able to log into the application and I land on dashboardpage$")
 public void i_validate_that_I_am_able_to_log_into_the_application_and_I_land_on_dashboardpage() {
     driver.getTitle();

 }

 @Then("^I validate that I get an error message \"([^\"]*)\"$")
 public void i_validate_that_I_get_an_error_message(String emsg) {
    

 }

 @After
 public void cleanUp() {
	 
     driver.close();
     driver.quit();
   }

}
