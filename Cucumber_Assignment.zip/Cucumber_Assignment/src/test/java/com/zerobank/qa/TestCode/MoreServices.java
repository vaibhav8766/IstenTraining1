package com.zerobank.qa.TestCode;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class MoreServices {
	 public static WebDriver driver;
	 @Given("^A \"([^\"]*)\" browser initialized$")
	 public void initiateBrowser(String browser)  {
	 //set system properties
		 System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");
	 driver =new ChromeDriver();
	 driver.manage().window().maximize();
	 driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	 }
	 
	 @And("^Open application \"([^\"]*)\"$")
	 public void OpenApp(String url) {        
	     //open URL into browser
	     driver.get(url);
	     assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");    
	 }

	 @And("^I click on MoreServices button on home page$")
	 public void clickOnMoreServicesButton() {
	     driver.findElement(By.xpath("//a[@id='online-banking']")).click(); 
	     }
	 
	 @Then("^I validate that I land on Online Banking page$")
	 public void i_validate_that_I_land_on_Online_Banking_page() {
	     assertEquals(driver.getTitle(), "Zero - Free Access to Online Banking");

	 }
}
