package com.zerobank.qa.TestCode;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Search_Box {
	public static WebDriver driver;
	@Given("^A \"([^\"]*)\" browser initialized$")
	 public void initiateBrowser(String browser)  {
	 //set system properties
		 System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");
	 driver =new ChromeDriver();
	 driver.manage().window().maximize();
	 driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	 }
	 
	 @And("^Open application \"([^\"]*)\"$")
	 public void OpenApp(String url) {        
	     //open URL into browser
	     driver.get(url);
	     assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");    
	 }
	 
	 
	 @Given("^I am on Home page$")
	 public void i_am_on_Home_page() {
	     assertEquals(driver.getTitle(),"Zero - Personal Banking - Loans - Credit Cards");    
	 }

	 @When("^I enter text as \"([^\"]*)\"$")
	 public void i_enter_text_as(String Text) {
	     driver.findElement(By.xpath("//input[@id='searchTerm']")).sendKeys(Text);
	   }
	 
	 @When("^Click on Enter$")
	 public void click_on_Enter_button() {
	     WebElement searchbox= driver.findElement(By.xpath("//input[@id='searchTerm']"));
	             searchbox.click();
	    		 searchbox.sendKeys(Keys.ENTER);
	     
}
	 @Then("^I should get searched Result$")
	 public void i_validate_that_I_get_searched_Result() {
	     
	     System.out.println(driver.getTitle());

	 } 
	 @After
	 public void cleanUp() {
		 
	     driver.close();
	     driver.quit();
	   }

}
