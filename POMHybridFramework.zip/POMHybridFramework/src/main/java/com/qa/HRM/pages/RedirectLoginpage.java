package com.qa.HRM.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.qa.HRM.base.TestBase;

public class RedirectLoginpage extends TestBase{

	
	
	@FindBy(xpath ="//h3[contains(text(),'Log in to ZeroBank')]")
	WebElement LinkAfterSearch;

public void assertOnlinebankingSerchResultTitle() {
		
		assertEquals(driver.getTitle(), "Zero - Log in");
	}
}
