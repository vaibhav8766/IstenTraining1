package com.qa.HRM.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.qa.HRM.base.TestBase;

public class OnlineBankingpage1 extends TestBase{
	
	@FindBy(linkText ="Zero - Free Access to Online Banking")
	WebElement LinkAfterSearch;

public void assertOnlinebankingSerchResultTitle() {
		
		assertEquals(driver.getTitle(), "The following pages were found for the query: online banking");
	}
}
