package com.qa.HRM.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.HRM.base.TestBase;

public class Dashboardpage extends TestBase {
	//object Repository

	@FindBy(xpath="//b[contains(text(),'Dashboard')]")
	WebElement Dashboard ;
	
	@FindBy(xpath="//b[contains(text(),'Recruitment')]")
	WebElement Recruitmenttab;
	
	@FindBy(xpath="//a[@id='menu_recruitment_viewCandidates']")
	WebElement candidate;
	
	@FindBy(xpath="input[@id='candidateSearch_candidateName']")
	WebElement candidatename;
	
	@FindBy(xpath="//input[@id='candidateSearch_keywords']")
	WebElement keywords;

	@FindBy(xpath="input[@id='candidateSearch_fromDate']")
	WebElement fromdate;
	
	@FindBy(xpath="input[@id='candidateSearch_toDate']")
	WebElement todate;

	@FindBy(xpath="input[@id='btnAdd']")
	WebElement eaddcandidata;
	
	
	
	//Initializing the page objects
	public Dashboardpage()  {
		PageFactory.initElements(driver, this);
	}
	
	public void assertLogInPageTitle() {
		assertEquals(driver.getTitle(), "OrangeHRM");
	}
	

	
	public void mhover()  {
		Actions act =new Actions(driver);
		act.moveToElement(Recruitmenttab).moveToElement(candidate).click().build().perform();
	}
	public addcandidatepage newcadidateadd() {
		  eaddcandidata.click();
		return new addcandidatepage();
		
	}	
	
	
	public void searchaddedcandidate()  {
		candidatename.sendKeys("vaibhav talankar");
		
	}
	
	
}
