package com.qa.HRM.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.HRM.base.TestBase;

public class addcandidatepage extends TestBase {

	//object repository
	@FindBy(xpath="//input[@id='addCandidate_firstName']")
	WebElement firstname ;
	
	@FindBy(xpath="//input[@id='addCandidate_lastName']")
	WebElement lastnamename ;
	//

	@FindBy(xpath="input[@id='addCandidate_email']")
	WebElement email ;
	
	@FindBy(xpath="input[@id='btnSave']")
	WebElement savebutton ;

	//Initializing the page objects
		public addcandidatepage()  {
			PageFactory.initElements(driver, this);
		}
	
	public void enterdata() {
	firstname.sendKeys("vaibhav");
	lastnamename.sendKeys("talankar");
	email.sendKeys("vaibhav@gmail.com");
		
	}
	
	public void clickonsavebutton()  {
		savebutton.click();
	}
	
	
}
