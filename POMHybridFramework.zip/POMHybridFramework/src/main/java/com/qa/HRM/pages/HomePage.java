package com.qa.HRM.pages;
import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.HRM.base.TestBase;

public class HomePage extends TestBase{

	//object Repository
	
	@FindBy(xpath = "//input[@id='txtUsername']")
	WebElement username;
	
	@FindBy(xpath = "//input[@id='txtPassword']")
	WebElement  password;
	
	@FindBy(xpath = "input[@id='btnLogin']")
	WebElement  Loginbutton;
	
	public HomePage()  {
		PageFactory.initElements(driver, this);
	}
	
	public void assertHomePageTitle() {
		assertEquals(driver.getTitle(), "OrangeHRM", "Home page title assert Failed");
	}
	
	public Dashboardpage clickOnSignInButton() {
		username.sendKeys(prop.getProperty("uuserid"));
		password.sendKeys(prop.getProperty("password"));
		Loginbutton.click();
		return new Dashboardpage();
	}
	
	
}

