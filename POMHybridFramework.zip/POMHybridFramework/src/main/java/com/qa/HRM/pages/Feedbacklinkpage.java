package com.qa.HRM.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.qa.HRM.base.TestBase;

public class Feedbacklinkpage extends TestBase{

  //object repository
	
	@FindBy(xpath = "//h2[contains(text(),'Search Results:')]")
	WebElement SearchResult1;
	
	
	public void assertFeedbackSerchResultTitle() {
		
		assertEquals(driver.getTitle(), "Zero - Search Tips");
	}
	
	
}
