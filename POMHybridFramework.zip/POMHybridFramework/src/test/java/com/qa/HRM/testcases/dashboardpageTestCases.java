package com.qa.HRM.testcases;

import static org.testng.Assert.assertTrue;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.HRM.base.TestBase;
import com.qa.HRM.pages.Dashboardpage;
import com.qa.HRM.pages.HomePage;
import com.qa.HRM.util.TestUtil;


public class dashboardpageTestCases extends TestBase{
	
	HomePage homePage;
	Dashboardpage dashboardpage;
	TestUtil testUtil;
	
	String sheetName ="Search";

	public  dashboardpageTestCases()  {       //Constructor
		super();   // calls the TestBase Class
		
	}
	
	 @BeforeMethod
	 public void setUp() 
	 {
		 initialization();
		 homePage =new HomePage();
		dashboardpage =new Dashboardpage();
		 testUtil= new TestUtil();
	 }
	 
	 @AfterMethod
	 public void cleanUp()  {
		 
		 driver.close();
		 driver.quit();
	 }
	
	 @Test
	 public void validateHomePage()  {
		 homePage.assertHomePageTitle();
	 }
	 
	 
	 @Test
	 public void signInButtonTest()   {
		 dashboardpage =homePage.clickOnSignInButton();
		 
	 }
	
	 
	
	 }
	 

