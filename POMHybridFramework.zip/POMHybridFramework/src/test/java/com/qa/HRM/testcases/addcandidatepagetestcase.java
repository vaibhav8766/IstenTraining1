package com.qa.HRM.testcases;

import javax.naming.directory.SearchResult;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.HRM.base.TestBase;
import com.qa.HRM.pages.Dashboardpage;
import com.qa.HRM.pages.HomePage;
import com.qa.HRM.pages.addcandidatepage;
import com.qa.HRM.util.TestUtil;



public class addcandidatepagetestcase extends TestBase{

	
	HomePage homePage;
	Dashboardpage dashboardpage;
	addcandidatepage Addcandidatepage;
	TestUtil testUtil;
	
	public  addcandidatepagetestcase()  {       
		super();   
	}
	
	@BeforeMethod
	 public void setUp() 
	 {
		 initialization();
		 homePage =new HomePage();
		 dashboardpage =new Dashboardpage();
		 
	 }
	
	@AfterMethod
	 public void cleanUp()  {
		
		 driver.close();
		 driver.quit();
	 }
	
	@Test 
	public void validatesearch ()  {
     
		
	}
	
    
}
