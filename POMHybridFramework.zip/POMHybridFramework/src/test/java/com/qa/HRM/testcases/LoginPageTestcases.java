package com.qa.HRM.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.HRM.base.TestBase;
import com.qa.HRM.pages.AccountSummaryPage;
import com.qa.HRM.pages.Dashboardpage;
import com.qa.HRM.pages.HomePage;
import com.qa.HRM.util.TestUtil;


public class LoginPageTestcases extends TestBase {
	HomePage homePage;
	Dashboardpage dashboardpage;
	
	
	
	
	public LoginPageTestcases()  {
		super();
	}
	
	@BeforeMethod
	public void beforeMethod()    {

		 initialization();
		 homePage =new HomePage();
		 dashboardpage =new Dashboardpage();
		 
	}
	
	@AfterMethod
	public void afterMethod()  {
		
		driver.close();
		driver.quit();
		
	}
	
	@Test
	public void validateLogInPage()  {
		dashboardpage =homePage.clickOnSignInButton();
		dashboardpage.assertLogInPageTitle();
	}
	
   
	
}
