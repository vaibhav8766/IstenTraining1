package assignmentrestapi;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.annotations.Test;

import io.restassured.filter.log.LogDetail;

public class GetSingleResourse {

	
	@Test
	public void valiadtesingleResourse()  {
		System.out.println("=========================THIS IS TEST 2 for Validate single Resourse =========================");
	baseURI ="https://gorest.co.in/";
			
			given()
			.get("/public/v1/users/100")
			
			.then()
			  .statusCode(200)
			  .log().ifValidationFails(LogDetail.STATUS)
			  .log().headers()
			  .log().body();
			
		}
}
