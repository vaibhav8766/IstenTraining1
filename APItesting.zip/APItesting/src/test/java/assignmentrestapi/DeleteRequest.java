package assignmentrestapi;

import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;

import io.restassured.filter.log.LogDetail;

public class DeleteRequest {
	
	 public String  userid="100";
	@Test (priority=1)
	public void testDeleteCreatedUser()   {
		
		System.out.println("=========================THIS IS TEST 5 for Delete Created User=========================");
		baseURI="https://gorest.co.in/";
		
	
		when()
		     .delete("/public/v1/users/" + userid )
	   .then()
		    .statusCode(204)
		    .log().ifValidationFails(LogDetail.STATUS)
		    .log().all();
	}
	
	@Test (priority =2)
	public void singleUserNotFound()  {
		
		System.out.println("=========================THIS IS TEST 6 for single User Not Found=========================");
		baseURI="https://reqres.in/api";
		when()
	     .get("/users/" + userid )
		   .then()
		    .statusCode(404)
		    .log().ifValidationFails(LogDetail.STATUS)
		    .log().all();
		
	}

}
