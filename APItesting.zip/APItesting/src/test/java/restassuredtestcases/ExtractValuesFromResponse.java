package restassuredtestcases;



public class ExtractValuesFromResponse {

	
}
