package restassuredtestcases;

import static  io.restassured.RestAssured.*;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
public class PostRequest {

// 	This  is Data 	we are passing in POST request 
//	 {
//    "name": "morpheus",
//    "job": "leader"
//    }
//   URI =/api/users
	
	
	@Test
	public void testPostCreateUser() {
		baseURI="https://reqres.in/api";
				
		JSONObject reqData =  new JSONObject();
		
		reqData.put("name", "John");
		reqData.put("Job", "Teacher");
		
		System.out.println(reqData.toJSONString());
		
		given()
		
		.header("Content-Type","application/json")
		.header("Connection","keep-alive")
//		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		.body(reqData.toJSONString())
		
		.when()
		     .post("/users")
		.then()
		     .statusCode(201)
		     .log().ifStatusCodeIsEqualTo(204)
			 .log().ifValidationFails(LogDetail.STATUS)
		     .log().all();    //It will log all response body
		
	} 
	
}
