package assignmentrestapi;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;

public class PostRegisterSucessful {

	@Test
	public void testPostResisterSucessful()   {
		System.out.println("=========================THIS IS TEST 9 for test Post Resister Sucessful=========================");
		baseURI="https://reqres.in/api";
		
		JSONObject reqData=  new JSONObject();
		
		reqData.put("email", "eve.holt@reqres.in");
		reqData.put("password", "pistol");
		
		System.out.println(reqData.toJSONString());
		
		given()
		
		.header("Content-Type","application/json")
		.header("Connection","keep-alive")
//		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		.body(reqData.toJSONString())
		
		.when()
		     .post("/register")
		.then()
		     .statusCode(200)
		     .log().ifValidationFails(LogDetail.STATUS)
		     .log().all();    //It will log all response bodyyu
		
	} 
		
	}

