package assignmentrestapi;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;

public class LoginUnsucessful {

	@Test
	public void testLoginUNSucess()  {
		System.out.println("=========================THIS IS TEST 8  for test Login UNSucess=========================");
		
		baseURI="https://reqres.in/api";
		
		JSONObject reqData=  new JSONObject();
		
		reqData.put("email", "peter@klaven");
		
		
		System.out.println(reqData.toJSONString());
		
		given()
		
		.header("Content-Type","application/json")
		.header("Connection","keep-alive")
//		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		.body(reqData.toJSONString())
		
		.when()
		     .post("/login")
		.then()
		
		     .statusCode(400)
		     .body("error",equalTo("Missing password"))
		     .log().ifValidationFails(LogDetail.STATUS)
		     .log().all();    //It will log all response body
		
	} 
}
