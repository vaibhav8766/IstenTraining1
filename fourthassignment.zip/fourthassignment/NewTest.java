package fourthassignment;

import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class NewTest {
	
	public WebDriver driver;

	//SetUp
    @BeforeTest
	public void setUp() {
	System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");
	
	driver =new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
	
	
	@Test (priority=1)
	public void LoginTest() {
		System.out.println("This is p1 Test");
	//open url 
	driver.get("http://zero.webappsecurity.com/");
	assertEquals(driver.getTitle(),"Zero - Personal Banking - Loans - Credit Cards");
	//Login Tests
    driver.findElement(By.id("signin_button")).click();
	driver.findElement(By.name("user_login")).sendKeys("username");
	driver.findElement(By.name("user_password")).sendKeys("password");
	driver.findElement(By.name("submit")).click();
	driver.findElement(By.id("details-button")).click();
    driver.findElement(By.id("proceed-link")).click();
    assertEquals(driver.getTitle(), "Zero - Account Summary");
	}
	
	 @Test(priority=2)
     public void PayBills() {
	System.out.println("This is p2 Test");
    driver.findElement(By.xpath("//a[contains(text(),'Pay Bills')]")).click();
    driver.findElement(By.xpath("//a[contains(text(),'Purchase Foreign Currency')]")).click();
    driver.findElement(By.xpath("//input[@id='purchase_cash']")).click();
    Alert TAlert =driver.switchTo().alert();
    String alerttxt=TAlert.getText();
    System.out.println("The alert is "+ alerttxt);
	TAlert.getText();
	TAlert.accept();
}
	
      // clean up
      @AfterTest
      public void cleanUp() {
      driver.close();
      driver.quit();
      }


}
