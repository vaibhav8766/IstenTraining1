package fourthassignment;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class FundTransfer {
  
	public WebDriver driver;
	
  @Test (priority=1,groups={"smoke"})
	public void Atest() {
	System.out.println("This is priority 1 Test");
	//open url 
	driver.get("http://zero.webappsecurity.com/");
	assertEquals(driver.getTitle(),"Zero - Personal Banking - Loans - Credit Cards");
	//Login Tests
  driver.findElement(By.id("signin_button")).click();
	driver.findElement(By.name("user_login")).sendKeys("username");
	driver.findElement(By.name("user_password")).sendKeys("password");
	driver.findElement(By.name("submit")).click();
	driver.findElement(By.id("details-button")).click();
  driver.findElement(By.id("proceed-link")).click();
  assertEquals(driver.getTitle(), "Zero - Account Summary");
	}
  
  @Test (priority=2,groups= {"smoke"})
  public void Btest() 
  {
	  System.out.println("This is priority 2 Test");
	  driver.findElement(By.linkText("Transfer Funds")).click();
	  
	 String Actual = driver.findElement(By.xpath("//h2[contains(text(),'Transfer Money & Make Payments')]")).getText();
	// String Expected ="Transfer Money & Make Payments";
	 Assert.assertEquals(Actual,"Transfer Money & Make Payments");
	 
  }
  
  @Test (priority=3,groups= {"smoke"})
  public void Ctest() 
  {
	 WebElement DropDownOne= driver.findElement(By.xpath("//select[@id='tf_fromAccountId']"));
	 Select dd1=new Select(DropDownOne);
	 dd1.selectByIndex(2);
	 
	 WebElement DropDownTwo= driver.findElement(By.xpath("//select[@id='tf_toAccountId']"));
	 Select dd2=new Select(DropDownTwo);
	 dd2.selectByIndex(2);
	 
	 driver.findElement(By.xpath("//input[@id='tf_amount']")).sendKeys("1000");
	 driver.findElement(By.xpath("//input[@id='tf_description']")).sendKeys("This is in Description");
	 
	 driver.findElement(By.xpath("//button[@id='btn_submit']")).click();
	 
	 WebElement GetTxt=driver.findElement(By.xpath("//h2[contains(text(),'Transfer Money & Make Payments - Verify')]"));
	 System.out.println(GetTxt);
	 
	driver.findElement(By.xpath("//button[@id='btn_submit']")).click();
	 
	String Result= driver.findElement(By.xpath("//div[contains(text(),'You successfully submitted your transaction.')]")).getText();
	System.out.println(Result);
	//String Expected=;
	
	Assert.assertEquals(Result, "You successfully submitted your transaction.");
	
	
	driver.findElement(By.partialLinkText("View transfers or ma")).isDisplayed();
  }
	
  
	 @Test (enabled=false,groups ={"Regression"})        
	 public void Cancel() {
	 driver.findElement(By.xpath("//a[@id='btn_cancel']")).click();
	 }
	 
	 @Test(groups ={"Regression"})
	 public void LoginFail() 
	 {
		 driver.get("http://zero.webappsecurity.com/");
		driver.switchTo().alert();
		
	 }
	 
	 @Test(groups ={"Regression"})
	 public void FailTwo() {
		 driver.get("http://zero.webappsecurity.com/");
			driver.switchTo().frame(0);
	 }
	 
	 @Test(groups ={"Regression"})
	 public void FailThree() {
		 driver.get("http://zero.webappsecurity.com/");
		driver.switchTo().frame(1);
	 }
	 
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("This is @BeforeMethod ");
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("This is @AfterMethod");
  }

  @BeforeClass
  public void beforeClass() {
	  System.out.println("This is  @BeforeClass");
  }

  @AfterClass
  public void afterClass() {
	  System.out.println("This is  @AfterClass ");
  }

 
	  
   @BeforeTest
		public void BeforeTest() {
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		
		driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
		}
  

  @AfterTest
  public void AfterTest() {
	  driver.close();
      driver.quit();
  }

  @BeforeSuite
  public void beforeSuite() {
	  System.out.println("This is ");
  }

  @AfterSuite
  public void afterSuite() {
	  System.out.println("This is  @AfterSuite");
  }

}
